package com.mobile.socialnetwork.presentation.post.presentation.person_list

import com.mobile.socialnetwork.core.util.Event

sealed class PostEvent : Event() {
    object OnLiked: PostEvent()
}