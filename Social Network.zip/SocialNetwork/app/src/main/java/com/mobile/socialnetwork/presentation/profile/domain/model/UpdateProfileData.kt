package com.mobile.socialnetwork.presentation.profile.domain.model

import com.mobile.socialnetwork.presentation.profile.domain.model.Skill

data class UpdateProfileData(
    val username: String,
    val bio: String,
    val gitHubUrl: String,
    val instagramUrl: String,
    val linkedInUrl: String,
    val skills: List<Skill>,
)
