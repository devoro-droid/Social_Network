package com.mobile.socialnetwork.presentation.post.presentation.util

import com.mobile.socialnetwork.core.util.Error

sealed class CommentError : Error() {
    object FieldEmpty: CommentError()
}
