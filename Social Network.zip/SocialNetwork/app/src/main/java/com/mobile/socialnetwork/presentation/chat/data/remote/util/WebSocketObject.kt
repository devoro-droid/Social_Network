package com.mobile.socialnetwork.presentation.chat.data.remote.util

enum class WebSocketObject {
    MESSAGE
}