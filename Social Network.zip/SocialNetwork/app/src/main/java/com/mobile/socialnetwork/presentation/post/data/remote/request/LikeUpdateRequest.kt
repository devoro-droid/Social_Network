package com.mobile.socialnetwork.presentation.post.data.remote.request

data class LikeUpdateRequest(
    val parentId: String,
    val parentType: Int
)
