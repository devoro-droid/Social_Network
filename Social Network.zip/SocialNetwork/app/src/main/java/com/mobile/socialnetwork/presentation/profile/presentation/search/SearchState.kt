package com.mobile.socialnetwork.presentation.profile.presentation.search

import com.mobile.socialnetwork.core.domain.models.UserItem

data class SearchState(
    val userItems: List<UserItem> = emptyList(),
    val isLoading: Boolean = false
)
