package com.mobile.socialnetwork.presentation.profile.domain.use_case

import com.mobile.socialnetwork.core.util.Resource
import com.mobile.socialnetwork.R
import com.mobile.socialnetwork.core.util.UiText
import com.mobile.socialnetwork.presentation.profile.domain.model.Skill
import com.mobile.socialnetwork.presentation.profile.domain.util.ProfileConstants

class SetSkillSelectedUseCase {

    operator fun invoke(
        selectedSkills: List<Skill>,
        skillToToggle: Skill
    ): Resource<List<Skill>> {
        val skillInList = selectedSkills.find { it.name == skillToToggle.name }
        if(skillInList != null) {
            return Resource.Success(selectedSkills - skillInList)
        }
        return if(selectedSkills.size >= ProfileConstants.MAX_SELECTED_SKILL_COUNT) {
            Resource.Error(uiText = UiText.StringResource(R.string.error_max_skills_selected))
        } else {
            Resource.Success(selectedSkills + skillToToggle)
        }
    }
}