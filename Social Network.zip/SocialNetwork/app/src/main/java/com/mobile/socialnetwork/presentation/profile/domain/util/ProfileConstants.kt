package com.mobile.socialnetwork.presentation.profile.domain.util

object ProfileConstants {

    const val MAX_SELECTED_SKILL_COUNT = 3

    val GITHUB_PROFILE_REGEX = "(https://)?(www\\.)?github\\.com/[A-z0-9_-]+/?".toRegex()
    val INSTAGRAM_PROFILE_REGEX = "(https?://)?(www\\.)?instagram\\.com/[a-z_\\-A-Z0-9]*".toRegex()

    const val SEARCH_DELAY = 700L
}