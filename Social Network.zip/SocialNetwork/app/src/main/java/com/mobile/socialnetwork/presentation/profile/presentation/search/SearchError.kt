package com.mobile.socialnetwork.presentation.profile.presentation.search

import com.mobile.socialnetwork.core.util.Error
import com.mobile.socialnetwork.core.util.UiText

data class SearchError(
    val message: UiText
): Error()
