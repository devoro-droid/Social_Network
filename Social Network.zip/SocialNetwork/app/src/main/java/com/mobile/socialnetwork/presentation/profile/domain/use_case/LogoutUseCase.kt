package com.mobile.socialnetwork.presentation.profile.domain.use_case

import com.mobile.socialnetwork.core.domain.repository.ProfileRepository

class LogoutUseCase(
    private val repository: ProfileRepository
) {

    operator fun invoke() {
        repository.logout()
    }
}