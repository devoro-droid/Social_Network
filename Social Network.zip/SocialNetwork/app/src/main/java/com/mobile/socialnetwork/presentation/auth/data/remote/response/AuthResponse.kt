package com.mobile.socialnetwork.presentation.auth.data.remote.response

data class AuthResponse(
    val userId: String,
    val token: String
)
