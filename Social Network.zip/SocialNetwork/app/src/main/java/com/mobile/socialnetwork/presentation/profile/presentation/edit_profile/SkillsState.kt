package com.mobile.socialnetwork.presentation.profile.presentation.edit_profile

import com.mobile.socialnetwork.presentation.profile.domain.model.Skill

data class SkillsState(
    val skills: List<Skill> = emptyList(),
    val selectedSkills: List<Skill> = emptyList()
)
