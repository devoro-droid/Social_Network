package com.mobile.socialnetwork.presentation.post.presentation.post_detail

data class CommentState(
    val isLoading: Boolean = false
)
