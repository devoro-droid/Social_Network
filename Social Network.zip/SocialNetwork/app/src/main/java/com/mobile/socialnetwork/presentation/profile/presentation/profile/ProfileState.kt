package com.mobile.socialnetwork.presentation.profile.presentation.profile

import com.mobile.socialnetwork.presentation.profile.domain.model.Profile

data class ProfileState(
    val profile: Profile? = null,
    val isLoading: Boolean = false,
    val isLogoutDialogVisible: Boolean = false
)
