package com.mobile.socialnetwork.presentation.post.domain.use_case

import com.mobile.socialnetwork.core.domain.models.Post
import com.mobile.socialnetwork.core.util.Constants
import com.mobile.socialnetwork.core.util.Resource
import com.mobile.socialnetwork.presentation.post.domain.repository.PostRepository

class GetPostsForFollowsUseCase(
    private val repository: PostRepository
) {

    suspend operator fun invoke(
        page: Int,
        pageSize: Int = Constants.DEFAULT_PAGE_SIZE
    ): Resource<List<Post>> {
        return repository.getPostsForFollows(page, pageSize)
    }
}