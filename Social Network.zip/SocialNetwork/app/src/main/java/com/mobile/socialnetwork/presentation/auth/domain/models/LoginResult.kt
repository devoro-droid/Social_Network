package com.mobile.socialnetwork.presentation.auth.domain.models

import com.mobile.socialnetwork.core.util.SimpleResource
import com.mobile.socialnetwork.presentation.auth.presentation.util.AuthError

data class LoginResult(
    val emailError: AuthError? = null,
    val passwordError: AuthError? = null,
    val result: SimpleResource? = null
)
