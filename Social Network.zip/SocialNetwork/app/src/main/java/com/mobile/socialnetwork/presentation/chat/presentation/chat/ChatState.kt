package com.mobile.socialnetwork.presentation.chat.presentation.chat

import com.mobile.socialnetwork.presentation.chat.domain.model.Chat

data class ChatState(
    val chats: List<Chat> = emptyList(),
    val isLoading: Boolean = false
)
