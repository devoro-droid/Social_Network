package com.mobile.socialnetwork.presentation.post.domain.use_case

import com.mobile.socialnetwork.core.domain.models.Comment
import com.mobile.socialnetwork.core.util.Resource
import com.mobile.socialnetwork.presentation.post.domain.repository.PostRepository

class GetCommentsForPostUseCase(
    private val repository: PostRepository
) {

    suspend operator fun invoke(postId: String): Resource<List<Comment>> {
        return repository.getCommentsForPost(postId)
    }
}