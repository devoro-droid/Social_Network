package com.mobile.socialnetwork.presentation.post.presentation.util

object PostConstants {

    const val MAX_POST_DESCRIPTION_LENGTH = 3000
}