package com.mobile.socialnetwork.presentation.post.presentation.main_feed

import com.mobile.socialnetwork.core.domain.models.Post

sealed class MainFeedEvent {
    data class LikedPost(val postId: String): MainFeedEvent()
    data class DeletePost(val post: Post): MainFeedEvent()
}
