package com.mobile.socialnetwork.presentation.profile.data.remote.request

data class FollowUpdateRequest(
    val followedUserId: String,
)
