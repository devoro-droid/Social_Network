package com.mobile.socialnetwork.presentation.chat.domain.use_case

import com.mobile.socialnetwork.presentation.chat.domain.repository.ChatRepository

class InitializeRepository(
    private val repository: ChatRepository
) {

    operator fun invoke() {
        repository.initialize()
    }
}