package com.mobile.socialnetwork.core.domain.states

import com.mobile.socialnetwork.core.util.Error

data class StandardTextFieldState(
    val text: String = "",
    val error: Error? = null
)
