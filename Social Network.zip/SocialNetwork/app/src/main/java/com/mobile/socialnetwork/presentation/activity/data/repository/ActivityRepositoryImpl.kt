package com.mobile.socialnetwork.presentation.activity.data.repository

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.mobile.socialnetwork.core.domain.models.Activity
import com.mobile.socialnetwork.core.util.Constants
import com.mobile.socialnetwork.presentation.activity.data.paging.ActivitySource
import com.mobile.socialnetwork.presentation.activity.data.remote.ActivityApi
import com.mobile.socialnetwork.presentation.activity.data.domain.repository.ActivityRepository
import kotlinx.coroutines.flow.Flow

class ActivityRepositoryImpl(
    private val api: ActivityApi
): ActivityRepository {

    override val activities: Flow<PagingData<Activity>>
        get() = Pager(PagingConfig(pageSize = Constants.DEFAULT_PAGE_SIZE)) {
            ActivitySource(api)
        }.flow
}