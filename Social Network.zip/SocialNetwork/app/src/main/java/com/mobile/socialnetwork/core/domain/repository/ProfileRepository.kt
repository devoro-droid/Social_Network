package com.mobile.socialnetwork.core.domain.repository

import android.net.Uri
import com.mobile.socialnetwork.core.domain.models.Post
import com.mobile.socialnetwork.core.domain.models.UserItem
import com.mobile.socialnetwork.core.util.Constants
import com.mobile.socialnetwork.core.util.Resource
import com.mobile.socialnetwork.core.util.SimpleResource
import com.mobile.socialnetwork.presentation.profile.domain.model.Profile
import com.mobile.socialnetwork.presentation.profile.domain.model.Skill
import com.mobile.socialnetwork.presentation.profile.domain.model.UpdateProfileData

interface ProfileRepository {

    suspend fun getPostsPaged(
        page: Int = 0,
        pageSize: Int = Constants.DEFAULT_PAGE_SIZE,
        userId: String
    ): Resource<List<Post>>

    suspend fun getProfile(userId: String): Resource<Profile>

    suspend fun updateProfile(
        updateProfileData: UpdateProfileData,
        bannerImageUri: Uri?,
        profilePictureUri: Uri?
    ): SimpleResource

    suspend fun getSkills(): Resource<List<Skill>>

    suspend fun searchUser(query: String): Resource<List<UserItem>>

    suspend fun followUser(userId: String): SimpleResource

    suspend fun unfollowUser(userId: String): SimpleResource

    fun logout()
}