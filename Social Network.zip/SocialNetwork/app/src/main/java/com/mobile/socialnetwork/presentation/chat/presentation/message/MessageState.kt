package com.mobile.socialnetwork.presentation.chat.presentation.message

import com.mobile.socialnetwork.presentation.chat.domain.model.Message

data class MessageState(
    val messages: List<Message> = emptyList(),
    val isLoading: Boolean = false,
    val canSendMessage: Boolean = false
)
