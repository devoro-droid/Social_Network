package com.mobile.socialnetwork.presentation.profile.domain.use_case

import com.mobile.socialnetwork.core.util.Resource
import com.mobile.socialnetwork.presentation.profile.domain.model.Skill
import com.mobile.socialnetwork.core.domain.repository.ProfileRepository

class GetSkillsUseCase(
    private val repository: ProfileRepository
) {

    suspend operator fun invoke(): Resource<List<Skill>> {
        return repository.getSkills()
    }
}