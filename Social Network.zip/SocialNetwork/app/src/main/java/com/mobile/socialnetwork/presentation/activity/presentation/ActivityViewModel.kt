package com.mobile.socialnetwork.presentation.activity.presentation

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.cachedIn
import com.mobile.socialnetwork.presentation.activity.data.domain.use_case.GetActivitiesUseCase
import com.mobile.socialnetwork.presentation.activity.presentation.ActivityEvent
import com.mobile.socialnetwork.presentation.activity.presentation.ActivityState
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class ActivityViewModel @Inject constructor(
    private val getActivities: GetActivitiesUseCase
) : ViewModel() {

    val activities = getActivities().cachedIn(viewModelScope)

    private val _state = mutableStateOf(ActivityState())
    val state: State<ActivityState> = _state

    fun onEvent(event: ActivityEvent) {
        when(event) {
            is ActivityEvent.ClickedOnUser -> {

            }
            is ActivityEvent.ClickedOnParent -> {

            }
        }
    }
}