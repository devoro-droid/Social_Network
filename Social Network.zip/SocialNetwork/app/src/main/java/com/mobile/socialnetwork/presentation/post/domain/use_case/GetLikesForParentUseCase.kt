package com.mobile.socialnetwork.presentation.post.domain.use_case

import com.mobile.socialnetwork.core.domain.models.UserItem
import com.mobile.socialnetwork.core.util.Resource
import com.mobile.socialnetwork.presentation.post.domain.repository.PostRepository

class GetLikesForParentUseCase(
    private val repository: PostRepository
) {

    suspend operator fun invoke(parentId: String): Resource<List<UserItem>> {
        return repository.getLikesForParent(parentId)
    }
}