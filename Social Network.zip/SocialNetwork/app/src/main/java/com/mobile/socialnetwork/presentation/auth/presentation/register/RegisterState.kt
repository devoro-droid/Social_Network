package com.mobile.socialnetwork.presentation.auth.presentation.register

data class RegisterState(
    val isLoading: Boolean = false
)