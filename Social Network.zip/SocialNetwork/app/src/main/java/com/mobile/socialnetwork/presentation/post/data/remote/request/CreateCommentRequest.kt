package com.mobile.socialnetwork.presentation.post.data.remote.request

data class CreateCommentRequest(
    val comment: String,
    val postId: String,
)
