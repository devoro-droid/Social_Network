package com.mobile.socialnetwork.presentation.chat.domain.use_case

import com.mobile.socialnetwork.core.util.Constants.DEFAULT_PAGE_SIZE
import com.mobile.socialnetwork.core.util.Resource
import com.mobile.socialnetwork.presentation.chat.domain.model.Message
import com.mobile.socialnetwork.presentation.chat.domain.repository.ChatRepository

class GetMessagesForChat(
    private val repository: ChatRepository
) {

    suspend operator fun invoke(
        chatId: String,
        page: Int,
        pageSize: Int = DEFAULT_PAGE_SIZE
    ): Resource<List<Message>> {
        return repository.getMessagesForChat(
            chatId, page, pageSize
        )
    }
}