package com.mobile.socialnetwork.core.util

interface Paginator<T> {

    suspend fun loadNextItems()
}