package com.mobile.socialnetwork.core.domain.use_case

import com.mobile.socialnetwork.core.util.SimpleResource
import com.mobile.socialnetwork.presentation.post.domain.repository.PostRepository

class DeletePost(
    private val repository: PostRepository
) {

    suspend operator fun invoke(postId: String): SimpleResource {
        return repository.deletePost(postId)
    }
}