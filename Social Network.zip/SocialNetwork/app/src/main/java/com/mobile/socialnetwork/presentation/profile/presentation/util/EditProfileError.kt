package com.mobile.socialnetwork.presentation.profile.presentation.util

import com.mobile.socialnetwork.core.util.Error

sealed class EditProfileError : Error() {
    object FieldEmpty: EditProfileError()
}
