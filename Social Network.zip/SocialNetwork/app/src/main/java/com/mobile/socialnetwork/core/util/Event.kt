package com.mobile.socialnetwork.core.util

abstract class Event