package com.mobile.socialnetwork.presentation.auth.presentation.login

data class LoginState(
    val isLoading: Boolean = false,
    val isPasswordVisible: Boolean = false
)
