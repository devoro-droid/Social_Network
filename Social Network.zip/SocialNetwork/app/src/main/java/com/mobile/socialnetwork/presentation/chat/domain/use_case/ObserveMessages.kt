package com.mobile.socialnetwork.presentation.chat.domain.use_case

import com.mobile.socialnetwork.presentation.chat.domain.model.Message
import com.mobile.socialnetwork.presentation.chat.domain.repository.ChatRepository
import kotlinx.coroutines.flow.Flow

class ObserveMessages(
    private val repository: ChatRepository
) {

    operator fun invoke(): Flow<Message> {
        return repository.observeMessages()
    }

}