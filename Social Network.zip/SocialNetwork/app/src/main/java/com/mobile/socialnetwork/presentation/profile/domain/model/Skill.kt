package com.mobile.socialnetwork.presentation.profile.domain.model

data class Skill(
    val name: String,
    val imageUrl: String
)
