package com.mobile.socialnetwork.core.domain.use_case

import com.mobile.socialnetwork.core.util.SimpleResource
import com.mobile.socialnetwork.core.domain.repository.ProfileRepository

class ToggleFollowStateForUserUseCase(
    private val repository: ProfileRepository
) {

    suspend operator fun invoke(userId: String, isFollowing: Boolean): SimpleResource {
        return if(isFollowing) {
            repository.unfollowUser(userId)
        } else {
            repository.followUser(userId)
        }
    }
}